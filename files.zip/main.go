package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
)

const aurBase = "https://aur.archlinux.org/rpc/v5"

func main() {
	if len(os.Args) < 3 {
		fmt.Println("Usage:")
		fmt.Println("  arts draw <package>   — install a package from AUR")
		fmt.Println("  arts erase <package>  — remove a package")
		os.Exit(1)
	}

	command := os.Args[1]
	pkg := os.Args[2]

	switch command {
	case "draw":
		if err := draw(pkg); err != nil {
			fmt.Fprintf(os.Stderr, "\033[31m✗ %s\033[0m\n", err)
			os.Exit(1)
		}
	case "erase":
		if err := erase(pkg); err != nil {
			fmt.Fprintf(os.Stderr, "\033[31m✗ %s\033[0m\n", err)
			os.Exit(1)
		}
	default:
		fmt.Fprintf(os.Stderr, "unknown command '%s'\n", command)
		os.Exit(1)
	}
}

func draw(name string) error {
	fmt.Printf("\033[35m🎨 Drawing '%s' onto your canvas...\033[0m\n\n", name)

	if err := checkExists(name); err != nil {
		return err
	}

	dir := filepath.Join(os.TempDir(), "arts-build", name)
	_ = os.RemoveAll(dir)

	fmt.Println("\033[34m  Cloning from AUR...\033[0m")
	if err := run("git", "clone", "https://aur.archlinux.org/"+name+".git", dir); err != nil {
		return fmt.Errorf("clone failed: %w", err)
	}

	fmt.Println("\033[34m  Building and installing...\033[0m")
	cmd := exec.Command("makepkg", "-si", "--noconfirm")
	cmd.Dir = dir
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("build failed: %w", err)
	}

	fmt.Printf("\n\033[32m✓ '%s' drawn successfully!\033[0m\n", name)
	return nil
}

func erase(name string) error {
	fmt.Printf("\033[35m🎨 Erasing '%s' from the canvas...\033[0m\n\n", name)
	if err := run("sudo", "pacman", "-R", "--noconfirm", name); err != nil {
		return fmt.Errorf("erase failed: %w", err)
	}
	fmt.Printf("\n\033[32m✓ '%s' erased.\033[0m\n", name)
	return nil
}

func checkExists(name string) error {
	endpoint := fmt.Sprintf("%s/info?arg[]=%s", aurBase, url.QueryEscape(name))
	resp, err := http.Get(endpoint)
	if err != nil {
		return fmt.Errorf("couldn't reach AUR: %w", err)
	}
	defer resp.Body.Close()

	var result struct {
		ResultCount int `json:"resultcount"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return fmt.Errorf("bad AUR response: %w", err)
	}
	if result.ResultCount == 0 {
		return fmt.Errorf("painting '%s' not found in the AUR", name)
	}
	return nil
}

func run(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}
